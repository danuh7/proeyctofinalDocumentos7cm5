import { useEffect, useState } from 'react'
import { useUser } from '../context/UserContext'
import { useNavigate } from 'react-router-dom'
import { saveAs } from 'file-saver'


function AdminDashboard() {
  const { usuario, esAdmin, cargando } = useUser()
  const navigate = useNavigate()

  const [ordenes, setOrdenes] = useState([])
  const [entregados, setEntregados] = useState([])
  const [productos, setProductos] = useState([])
  const [mensaje, setMensaje] = useState('')
  const [modoEdicion, setModoEdicion] = useState(false)
  const [idEditar, setIdEditar] = useState(null)

  const [form, setForm] = useState({
    nombre: '',
    descripcion: '',
    precio: '',
    imagen: '',
    temporada_flor: '',
    origen: '',
    pais: ''
  })

  useEffect(() => {
    if (!cargando && (!usuario || usuario.rol !== 'admin')) {
      navigate('/')
    }
  }, [cargando, usuario, navigate])

  useEffect(() => {
    const fetchOrdenes = async () => {
      try {
        const res = await fetch('${import.meta.env.VITE_API_URL}/admin/ordenes', {
          headers: { rol: usuario.rol }
        })
        const data = await res.json()
        if (res.ok) setOrdenes(data)
      } catch (err) {
        console.error('Error al obtener pedidos:', err)
      }
    }

    const fetchEntregados = async () => {
      try {
        const res = await fetch('${import.meta.env.VITE_API_URL}/admin/ordenes/entregadas', {
          headers: { rol: usuario.rol }
        })
        const data = await res.json()
        if (res.ok) setEntregados(data)
      } catch (err) {
        console.error('Error al obtener entregados:', err)
      }
    }

    const fetchProductos = async () => {
      try {
        const res = await fetch('${import.meta.env.VITE_API_URL}/productos', {
          headers: { rol: usuario.rol }
        })
        const data = await res.json()
        if (res.ok) setProductos(data)
      } catch (err) {
        console.error('Error al obtener productos:', err)
      }
    }

    if (esAdmin) {
      fetchOrdenes()
      fetchEntregados()
      fetchProductos()
    }
  }, [esAdmin, usuario])

  const entregarPedido = async (id) => {
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/admin/ordenes/entregar/${id}`, {
        method: 'POST',
        headers: { rol: usuario.rol }
      })
      if (!res.ok) throw new Error('Error al entregar el pedido')
      setOrdenes(prev => prev.filter(o => o.id !== id))

      const nuevosEntregados = await fetch('${import.meta.env.VITE_API_URL}/admin/ordenes/entregadas', {
        headers: { rol: usuario.rol }
      })
      const data = await nuevosEntregados.json()
      if (nuevosEntregados.ok) setEntregados(data)

      alert('✅ Pedido entregado correctamente')
    } catch (err) {
      console.error(err)
      alert('❌ No se pudo entregar el pedido')
    }
  }

  const eliminarCompra = async (id) => {
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/admin/ordenes/entregadas/${id}`, {
        method: 'DELETE',
        headers: { rol: usuario.rol }
      })
      if (res.ok) setEntregados(prev => prev.filter(o => o.id !== id))
    } catch (err) {
      console.error(err)
      alert('❌ Error al eliminar compra')
    }
  }

  const eliminarProducto = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar este producto?')) return
    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/admin/productos/${id}`, {
        method: 'DELETE',
        headers: { rol: usuario.rol }
      })
      if (res.ok) {
        setProductos(prev => prev.filter(p => p.id !== id))
        setMensaje('✅ Producto eliminado correctamente')
      } else {
        setMensaje('❌ Error al eliminar producto')
      }
    } catch (err) {
      console.error(err)
      setMensaje('❌ Error al eliminar producto')
    }
  }

  const editarProducto = (producto) => {
    setModoEdicion(true)
    setIdEditar(producto.id)
    setForm({
      nombre: producto.nombre,
      descripcion: producto.descripcion || '',
      precio: producto.precio,
      imagen: producto.imagen || '',
      temporada_flor: producto.temporada_flor,
      origen: producto.origen,
      pais: producto.pais
    })
  }

  const cancelarEdicion = () => {
    setModoEdicion(false)
    setIdEditar(null)
    setForm({
      nombre: '',
      descripcion: '',
      precio: '',
      imagen: '',
      temporada_flor: '',
      origen: '',
      pais: ''
    })
    setMensaje('')
  }

  const handleSubmit = async e => {
    e.preventDefault()
    setMensaje('')
    const { nombre, descripcion, precio, imagen, temporada_flor, origen, pais } = form

    if (!nombre || !precio || !temporada_flor || !origen || !pais) {
      setMensaje('❌ Faltan campos obligatorios')
      return
    }

    const precioNumerico = parseFloat(precio)
    if (isNaN(precioNumerico) || precioNumerico <= 0) {
      setMensaje('❌ El precio debe ser un número válido mayor a cero')
      return
    }

    const imagenFinal = imagen.trim() || 'https://via.placeholder.com/150'
    const metodo = modoEdicion ? 'PUT' : 'POST'
    const url = modoEdicion
      ? `${import.meta.env.VITE_API_URL}/admin/productos/${idEditar}`
      : '${import.meta.env.VITE_API_URL}/admin/productos'

    try {
      const res = await fetch(url, {
  method: metodo,
  headers: {
    'Content-Type': 'application/json',
    rol: usuario.rol
  },
  body: JSON.stringify({
    nombre,
    descripcion,
    precio: precioNumerico,
    imagen: imagenFinal,
    temporada_flor,
    origen,
    pais
  })
})

      const data = await res.json()
      if (res.ok) {
        setMensaje(modoEdicion ? '✅ Producto actualizado' : '✅ Producto agregado')
        setForm({
          nombre: '',
          descripcion: '',
          precio: '',
          imagen: '',
          temporada_flor: '',
          origen: '',
          pais: ''
        })
        setModoEdicion(false)
        setIdEditar(null)

        const refresh = await fetch('${import.meta.env.VITE_API_URL}/productos')
        const dataRefreshed = await refresh.json()
        setProductos(dataRefreshed)
      } else {
        setMensaje('❌ Error: ' + data.error)
      }
    } catch (err) {
      console.error(err) // ✅ Log the error for debugging
      setMensaje('❌ Error al conectar con el servidor')
    }
  }

  const exportarPDF = async () => {
  try {
    const res = await fetch('${import.meta.env.VITE_API_URL}/admin/ordenes/exportar-pdf?desde=2024-01-01&hasta=2025-12-31', {
      headers: { rol: usuario.rol }
    })
    const blob = await res.blob()
    saveAs(blob, 'pedidos_entregados.pdf')
    alert('✅ PDF generado y descargado correctamente.')
  } catch (error) {
    console.error('Error al exportar PDF:', error)
    alert('❌ Error al exportar el PDF.')
  }
}


  if (cargando) return <div style={{ padding: '20px' }}>Cargando...</div>
  if (!cargando && usuario?.rol !== 'admin') return <div style={{ padding: '20px' }}>No tienes permisos de administrador</div>

  return (
    <div style={{ padding: '20px' }}>
      <h1>🛠️ Panel de Administrador</h1>
      <p>Bienvenido, {usuario?.nombre}</p>

      {/* PEDIDOS */}
      <h2>📦 Pedidos recientes</h2>
      {ordenes.length === 0 ? (
        <p>No hay pedidos recientes</p>
      ) : (
        ordenes.map(o => (
          <div key={o.id} style={{ marginBottom: '20px', paddingBottom: '15px', borderBottom: '1px solid #ccc' }}>
            <h4>🧾 Orden #{o.id}</h4>
            <p><strong>Cliente:</strong> {o.cliente}</p>
            <p><strong>Fecha:</strong> {new Date(o.fecha).toLocaleString()}</p>
            <p><strong>Total:</strong> ${Number(o.total).toFixed(2)}</p>
            <ul>
              {o.productos.map((p, i) => (
                <li key={i}>{p.producto} x{p.cantidad} → ${p.precio.toFixed(2)}</li>
              ))}
            </ul>
            <button onClick={() => entregarPedido(o.id)} style={{ marginTop: '10px' }}>
              ✅ Entregar pedido
            </button>
          </div>
        ))
      )}

      <h2>📬 Pedidos entregados</h2>
      {entregados.length === 0 ? (
        <p>No hay pedidos entregados aún</p>
      ) : (
        entregados.map(o => (
          <div key={o.id} style={{ marginBottom: '20px', paddingBottom: '15px', borderBottom: '1px solid #ccc' }}>
            <h4>📦 Pedido #{o.orden_id}</h4>
            <p><strong>Cliente:</strong> {o.cliente}</p>
            <p><strong>Fecha:</strong> {new Date(o.fecha).toLocaleString()}</p>
            <p><strong>Total:</strong> ${Number(o.total).toFixed(2)}</p>
            <ul>
              {(Array.isArray(o.productos) ? o.productos : JSON.parse(o.productos)).map((p, i) => (
                <li key={i}>{p.producto} x{p.cantidad} → ${p.precio.toFixed(2)}</li>
              ))}
            </ul>
            <button onClick={() => eliminarCompra(o.id)} style={{ marginTop: '10px', background: '#d32f2f', color: 'white' }}>
              🗑️ Eliminar compra
            </button>
          </div>
        ))
      )}

      {/* Botón para exportar PDF */}
    <button
      onClick={exportarPDF}
      style={{
        marginBottom: '20px',
        background: '#4CAF50',
        color: 'white',
        padding: '10px',
        border: 'none',
        borderRadius: '5px',
        cursor: 'pointer'
      }}
    >
      📄 Exportar pedidos entregados a PDF
    </button>

      {/* FORMULARIO PRODUCTOS */}
      <h2 style={{ marginTop: '40px' }}>{modoEdicion ? '✏️ Editar producto' : '➕ Agregar nuevo producto'}</h2>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxWidth: '300px', background: modoEdicion ? '#fffbe6' : 'inherit', padding: '10px' }}>
        <input type="text" placeholder="Nombre" value={form.nombre} onChange={e => setForm({ ...form, nombre: e.target.value })} required />
        <input type="text" placeholder="Descripción" value={form.descripcion} onChange={e => setForm({ ...form, descripcion: e.target.value })} />
        <input type="number" placeholder="Precio" value={form.precio} onChange={e => setForm({ ...form, precio: e.target.value })} required />
        <input type="text" placeholder="URL de imagen" value={form.imagen} onChange={e => setForm({ ...form, imagen: e.target.value })} />
        <select value={form.temporada_flor} onChange={e => setForm({ ...form, temporada_flor: e.target.value })} required>
          <option value="">Temporadad de Flor</option>
          <option value="primavera">Primavera</option>
          <option value="verano">Verano</option>
        </select>
        <select value={form.origen} onChange={e => setForm({ ...form, origen: e.target.value })} required>
          <option value="">Origen</option>
          <option value="nacional">Nacional</option>
          <option value="internacional">Internacional</option>
        </select>
        <input type="text" placeholder="País" value={form.pais} onChange={e => setForm({ ...form, pais: e.target.value })} required />
        <button type="submit">{modoEdicion ? 'Actualizar producto' : 'Guardar producto'}</button>
        {modoEdicion && (
          <button type="button" onClick={cancelarEdicion} style={{ background: '#aaa', color: 'white' }}>
            ❌ Cancelar edición
          </button>
        )}
        {mensaje && <p>{mensaje}</p>}
      </form>

      {/* LISTA DE PRODUCTOS */}
      <h2 style={{ marginTop: '40px' }}>📃 Productos registrados</h2>
      {productos.length === 0 ? (
        <p>No hay productos aún</p>
      ) : (
        productos.map(p => (
          <div key={p.id} style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '10px' }}>
            <h4>{p.nombre} (${p.precio})</h4>
            <p>{p.descripcion}</p>
            <p><strong>Temporada:</strong> {p.temporada_flor}</p>
            <p><strong>Origen:</strong> {p.origen} – {p.pais}</p>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => editarProducto(p)}>✏️ Editar</button>
              <button onClick={() => eliminarProducto(p.id)} style={{ background: '#d32f2f', color: 'white' }}>🗑️ Eliminar</button>
            </div>
          </div>
        ))
      )}
    </div>

    
  )
}

export default AdminDashboard
